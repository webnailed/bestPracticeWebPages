'use strict';

angular.module('justGivingApp')
  .controller('accountCtrl', function ($scope) {
  });